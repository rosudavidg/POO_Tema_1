package game.map;

public enum Direction {
    UP,         // Sus
    DOWN,       // Jos
    LEFT,       // Stanga
    RIGHT,      // Dreapta
    NODIRECTION // Nu va muta
}
